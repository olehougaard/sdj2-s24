package dk.via.wordle;

public enum Result {
    MISS, WRONG_PLACE, CORRECT
}
